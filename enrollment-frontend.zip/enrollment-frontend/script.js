document.getElementById('enrollmentForm').addEventListener('submit', function (e) {
  e.preventDefault();

  const formData = {
    name: document.getElementById('name').value,
    subjects12th: document.getElementById('subjects12th').value,
    previousCourse: document.getElementById('previousCourse').value,
    desiredCourse: document.getElementById('desiredCourse').value,
    frequencyYear: document.getElementById('frequencyYear').value
  };

  console.log('Form Data Submitted:', formData);

  // Simulate success message
  document.getElementById('responseMessage').innerText = "Enrollment submitted successfully!";
  document.getElementById('enrollmentForm').reset();
});
